package com.avanger.DB_connecter;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB_conecter {
		
			public static Connection createConnection() {
				System.out.println("[+]DB_connection File.....");
				System.out.println("   [-]createConnection function...");
				Connection conn = null;
				String DB_name="Deepak";
				String url="jdbc:mysql://229.51.150.1:8999/"+DB_name;
				//String url="jdbc:mysql://localhost:3306/"+DB_name;
				String username="Deepak";
				String pass="@#$%&%$#@";
				try {
					Class.forName("com.mysql.jdbc.Driver");
					conn = DriverManager.getConnection(url,username,pass);
				} catch (Exception e) {
					// TODO: handle exception
					System.out.println("   [!]DB connecction Creatin error");
					e.printStackTrace();
				}
				return conn;
			}
}

/*
*
Table Command :-
Table-1)User_list table:-
 create table team_ID (ID INT NOT NULL AUTO_INCREMENT,Username VARCHAR(100) NOT NULL,Password VARCHAR(40) NOT NULL,Reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (ID))
       -OR-
 create table team_ID(ID int(10) UNSIFNED AUTO_INCREMENT PRIMARY KEY,Username VARCHAR(100) NOT NULL,
             Password VARCHAR(100) NOT NULL,Reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP);

Table-2)Working Case Table:-
		create table case_data (case_id INT NOT NULL AUTO_INCREMENT,
		Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		Engineer_Location VARCHAR(40) NOT NULL,
		Engineer_Name VARCHAR(40) NOT NULL,
		User_Name_Email_ID_Contact_Number VARCHAR(50) NOT NULL,
		Reported_Issue_Type VARCHAR(20) NOT NULL,
		Reported_Issue_Description VARCHAR(100) NOT NULL,
		Solution_Given VARCHAR(100) NOT NULL,
		Issue_Status VARCHAR(20) NOT NULL,
		Remark VARCHAR(100) NOT NULL,
		PRIMARY KEY (case_id));
		
		

*
*
*/

/*
 * 
 mysql> desc case_data;
+-----------------------------------+--------------+------+-----+-------------------+-----------------------------+
| Field                             | Type         | Null | Key | Default           | Extra                       |
+-----------------------------------+--------------+------+-----+-------------------+-----------------------------+
| case_id                           | int(11)      | NO   | PRI | NULL              | auto_increment              |
| Date                              | timestamp    | NO   |     | CURRENT_TIMESTAMP | on update CURRENT_TIMESTAMP |
| Engineer_Location                 | varchar(40)  | NO   |     | NULL              |                             |
| Engineer_Name                     | varchar(40)  | NO   |     | NULL              |                             |
| User_Name_Email_ID_Contact_Number | varchar(50)  | NO   |     | NULL              |                             |
| Reported_Issue_Type               | varchar(20)  | NO   |     | NULL              |                             |
| Reported_Issue_Description        | varchar(100) | NO   |     | NULL              |                             |
| Solution_Given                    | varchar(100) | NO   |     | NULL              |                             |
| Issue_Status                      | varchar(20)  | NO   |     | NULL              |                             |
| Remark                            | varchar(100) | NO   |     | NULL              |                             |
+-----------------------------------+--------------+------+-----+-------------------+-----------------------------+
10 rows in set (0.53 sec)

mysql> 
mysql> desc team_ID;
+----------+--------------+------+-----+-------------------+-----------------------------+
| Field    | Type         | Null | Key | Default           | Extra                       |
+----------+--------------+------+-----+-------------------+-----------------------------+
| ID       | int(11)      | NO   | PRI | NULL              | auto_increment              |
| Username | varchar(100) | NO   |     | NULL              |                             |
| Password | varchar(40)  | NO   |     | NULL              |                             |
| Reg_date | timestamp    | NO   |     | CURRENT_TIMESTAMP | on update CURRENT_TIMESTAMP |
+----------+--------------+------+-----+-------------------+-----------------------------+
4 rows in set (0.14 sec)
 * 
 */
