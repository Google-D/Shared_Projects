package com.avanger.var;

public class check_and_get {
	
	private String locatin;
	private Boolean check_log;
	private int id;
	
	public Boolean getCheck_log() {
		return check_log;
	}
	public void setcheck_log(Boolean check_log) {
		this.check_log = check_log;
	}
	
	public String getLocatin() {
		return locatin;
	}
	public void setLocatin(String locatin) {
		this.locatin = locatin;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

}
