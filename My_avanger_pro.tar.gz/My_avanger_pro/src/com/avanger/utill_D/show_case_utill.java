package com.avanger.utill_D;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.avanger.DB_connecter.DB_conecter;
import com.avanger.var.show_var;

public class show_case_utill {

	public static List<show_var> get_all_case(String en,String lo){
		System.out.println("[+]In show_case_util file .....");
		System.out.println("   [-]");
		
		List<show_var> list=new ArrayList<show_var>();
		try {
			Connection conn = DB_conecter.createConnection();
			String sql = "SELECT case_id,Date, User_Name_Email_ID_Contact_Number,Reported_Issue_Type, Solution_Given,Issue_Status FROM case_data where Engineer_Location=? and Engineer_Name=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, en);
			pst.setString(2, lo);
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				show_var t = new show_var();
				t.setId(rs.getInt("case_id"));
				t.setDate(rs.getString("Date"));
				t.setEmail_ID(rs.getString("User_Name_Email_ID_Contact_Number"));
				t.setRepoted_issue(rs.getString("Reported_Issue_Type"));
				t.setSolution(rs.getString("Solution_Given"));
				t.setCase_status(rs.getString("Issue_Status"));
				list.add(t);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}

}
