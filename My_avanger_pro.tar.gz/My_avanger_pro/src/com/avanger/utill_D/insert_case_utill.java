package com.avanger.utill_D;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.avanger.DB_connecter.DB_conecter;
import com.avanger.var.check_and_get;
import com.avanger.var.insert_case_var;
import com.avanger.var.login_var;

public class insert_case_utill {
public static Boolean put_case(insert_case_var ic) {
		System.out.println("[+]Insert_case_utill File.......");
		System.out.println("   [-]Put_case Function.......");
			try {
				Connection con=DB_conecter.createConnection();
				String sql= "insert into case_data (Engineer_location,Engineer_Name, User_Name_Email_ID_Contact_Number,Reported_Issue_Type,Reported_Issue_Description,Solution_Given,Issue_Status,Remark) value(?,?,?,?,?,?,?,?)";
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1,ic.getEng_name());
				pst.setString(2,ic.getEng_location());
				pst.setString(3,ic.getEmail_ID());
				pst.setString(4,ic.getRepoted_issue());
				pst.setString(5,ic.getIssue_desc());
				pst.setString(6,ic.getSolution());
				pst.setString(7,ic.getCase_status());
				pst.setString(8,ic.getRemark());	
				int result1=pst.executeUpdate();
				System.out.println("   [-]Put_case Function process Done....");
				con.close();
				return true;
			} catch (Exception e) {
				// TODO: handle exception	
				System.out.println("   [!]Put_case Function error.......");
			}
		return false;
	}//end of "put_case"


public static check_and_get login_check_get_loc(login_var lv) {
	System.out.println("[+]Insert_case_utill File.......");
	System.out.println("   [-]login_check_get_loc function .....");
	System.out.println("   [-]Getting USername="+lv.getUsername()+" and Password= "+lv	.getPassword());
	
	check_and_get cg=new check_and_get();
	cg.setcheck_log(false);
		try {
			Connection con=DB_conecter.createConnection();
			String sql= "select * from team_ID where Username=? and Password=?";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1,lv.getUsername());
			pst.setString(2, lv.getPassword());
			ResultSet rs=pst.executeQuery();
			System.out.println("[+]Connection Done.");
			while (rs.next()) {
				if(lv.getUsername().equalsIgnoreCase(rs.getString("Username"))||lv.getPassword().equalsIgnoreCase(rs.getString("Password")))
					{
						cg.setLocatin(rs.getString("location"));
						cg.setcheck_log(true);
						System.out.println("[+]get_location from DB ="+cg.getLocatin());
					}
			}
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("   [!]login_check_get_loc function error .....");
		}
	return cg;
	}//end of "login_check_get_loc"


public static String get_location(HttpSession st) {
	System.out.println("[+]Insert_case_utill File.......");
	System.out.println("   [-]login_check_get_loc function .....");
	
	String location = null;
		try {
			Connection con=DB_conecter.createConnection();
			String sql= "select * from team_ID where Username=? and Password=?";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1,(String)st.getAttribute("session_get_id"));
			pst.setString(2, (String)st.getAttribute("session_id"));
			ResultSet rs=pst.executeQuery();
			System.out.println("[+]Connection Done.");
			while (rs.next()) {
				if(((String) st.getAttribute("session_get_id")).equalsIgnoreCase(rs.getString("Username"))||((String) st.getAttribute("session_id")).equalsIgnoreCase(rs.getString("Password")))
					{
					
						location=rs.getString("location");
						System.out.println("[+]get_location from DB ="+location);
					}
			}
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("   [!]login_check_get_loc function error .....");
		}
	return location;
	}//end of "login_check_get_loc"




}

/*
 * 
 * insert into case_data(Engineer_location,Engineer_Name, User_Name_Email_ID_Contact_Number,Reported_Issue_Type,Reported_Issue_Description,Solution_Given,Issue_Status,Remark)
 * 
 * 
 */
