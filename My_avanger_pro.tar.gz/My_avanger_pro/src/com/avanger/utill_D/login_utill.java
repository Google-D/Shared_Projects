package com.avanger.utill_D;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.catalina.tribes.transport.RxTaskPool;

import com.avanger.DB_connecter.DB_conecter;
import com.avanger.var.login_var;

public class login_utill {

	
	public static Boolean login_check(login_var lv) {
		System.out.println("[+]login_utill File.......");
		System.out.println("   [-]login_check function .....");
			try {
				Connection con=DB_conecter.createConnection();
				String sql= "select * from team_ID where Username=? and Password=?";
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1,lv.getUsername());
				pst.setString(2, lv.getPassword());
				ResultSet rs=pst.executeQuery();
				while (rs.next()) {
					if(lv.getUsername().equalsIgnoreCase(rs.getString("Username"))||lv.getPassword().equalsIgnoreCase(rs.getString("Password")))
						{
							return true;
						}
				}
				con.close();
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("   [!]login_check function error.....");
			}
		
		
		return false;
	}
}
