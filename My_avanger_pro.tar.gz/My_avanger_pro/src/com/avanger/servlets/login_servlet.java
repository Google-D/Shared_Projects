package com.avanger.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.avanger.utill_D.login_utill;
import com.avanger.var.login_var;

@WebServlet("/login_servlet")
public class login_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		 
		 String action=request.getParameter("Login");
		 if(action.equalsIgnoreCase("Login")){
			 
			 String user=request.getParameter("uname");
			 String pass=request.getParameter("pass");
			 
			 System.out.println(user);
			 System.out.println(pass);
			 
			 login_var lov=new login_var();
			 lov.setUsername(user);
			 lov.setPassword(pass);
			 
			 if(login_utill.login_check(lov)) {
				 HttpSession session=request.getSession();
				 session.setAttribute("session_get_id", user);
				 session.setAttribute("session_id", pass);
				 response.sendRedirect("home.jsp");
				 System.out.println("[@]login process Done");
				 
			 }else {
				 response.sendRedirect("index.jsp");
				 System.out.println("[!]login process Fail!");
			}
			 
			 
		 }
		
      	}

}
