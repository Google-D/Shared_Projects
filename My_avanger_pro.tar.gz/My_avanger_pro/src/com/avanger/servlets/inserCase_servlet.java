package com.avanger.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JEditorPane;
import javax.websocket.Session;

import com.avanger.utill_D.insert_case_utill;
import com.avanger.utill_D.show_case_utill;
import com.avanger.var.check_and_get;
import com.avanger.var.insert_case_var;
import com.avanger.var.login_var;
import com.avanger.var.show_var;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;

/**
 * Servlet implementation class inserCase_servlet
 */
@WebServlet("/inserCase")
public class inserCase_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session_get =request.getSession();
		
		System.out.println("[+]Ented in get method");
		System.out.println(session_get.getAttribute("session_get_id"));
		System.out.println((String)session_get.getAttribute("session_id"));
		
		if(((String)session_get.getAttribute("session_get_id")).equalsIgnoreCase(null)||((String)session_get.getAttribute("session_get_id")).equalsIgnoreCase(null)) 
{
			
			System.out.println("All data null");
	}else {

		login_var lv2=new login_var();
		lv2.setUsername((String)session_get.getAttribute("session_get_id"));
		lv2.setPassword((String)session_get.getAttribute("session_id"));
		check_and_get cag2 = insert_case_utill.login_check_get_loc(lv2);
		System.out.println("[+]Authantication="+cag2.getCheck_log());
		if(cag2.getCheck_log()) {
			System.out.println("[+]User authantication Done.....");
		
		System.out.println("[+]Data getting from DB,........");
		String una=(String)session_get.getAttribute("session_get_id");
		String loca=cag2.getLocatin();		
		
		ArrayList<show_var> mylist =new ArrayList<show_var>(); 
				mylist = (ArrayList<show_var>) show_case_utill.get_all_case(una, loca);
		
		System.out.println("[+]Data getting process Done,........");
		//jsone convertion started.
		System.out.println("[*]jsone conversion start.");

		Gson json= new Gson();
		JsonElement element=json.toJsonTree(mylist);
		System.out.println(element);
		JsonArray jsa=element.getAsJsonArray();
		//response.setContentType("application/json");
		response.setContentType("text/plain");
		response.getWriter().print(jsa);
		}
	  }	
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	  //	doGet(request, response);
		System.out.println("[+]InserCase servlet File.......");
		PrintWriter out=response.getWriter();
		
		//out.println("[!]Connected to Server.");
		HttpSession session =request.getSession();
		String work=request.getParameter("insert");
		
		if(((String)session.getAttribute("session_get_id")).equalsIgnoreCase(null)||((String)session.getAttribute("session_get_id")).equalsIgnoreCase(null))
		{
			
				System.out.println("All data null");
		}else {
			
		
		
		//Debugging section
		System.out.println(session.getAttribute("session_get_id"));
		System.out.println((String)session.getAttribute("session_id"));
		System.out.println(request.getParameter("email"));
		System.out.println(request.getParameter("select1"));
		System.out.println(request.getParameter("Description"));
		System.out.println(request.getParameter("Solution"));
		System.out.println(request.getParameter("select2"));
		System.out.println(request.getParameter("remark"));
		//Debugging secssion end.
		
		
		login_var lv=new login_var();
		lv.setUsername((String)session.getAttribute("session_get_id"));
		lv.setPassword((String)session.getAttribute("session_id"));
		check_and_get cag = insert_case_utill.login_check_get_loc(lv);
		System.out.println("[+]Authantication="+cag.getCheck_log());
		if(cag.getCheck_log()) {
			System.out.println("[+]User authantication Done.....");
			//out.println("[+]Authantication Done..");
			
			
			System.out.println("[+]Case Data getting and setting process started.....");
			//out.println("[+]Data setting process starting..");
			
				insert_case_var icv=new insert_case_var();
				icv.setEmail_ID(request.getParameter("email"));
				icv.setRepoted_issue(request.getParameter("select1"));
				icv.setIssue_desc(request.getParameter("Description"));
				icv.setSolution(request.getParameter("Solution"));
				icv.setCase_status(request.getParameter("select2"));
				icv.setRemark(request.getParameter("remark"));
				icv.setEng_name((String)session.getAttribute("session_get_id"));
				icv.setEng_location(cag.getLocatin());
				
				Boolean result=insert_case_utill.put_case(icv);
				System.out.println("   [-]Last Result Value ="+result);
			
				if(result) {
					out.println("Case Add Sucessfully.");
				}else {
					//out.print("<script type='text/javascript'> document.getElementById('smg').innerHTML = 'Not able to add.';</script>");
					out.println("Not able to add.");
				}
			
		}
		
		}
	
		}
		
	}

